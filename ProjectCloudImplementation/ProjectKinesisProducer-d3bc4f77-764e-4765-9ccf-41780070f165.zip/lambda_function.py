import boto3
import json
import random
import string
from datetime import datetime, timedelta

def generate_random_sales_data():
    # Generate random store and department data
    store_id = random.randint(1, 50)
    department_id = random.randint(1, 10)
    store_size = random.choice(["small", "medium", "large"])
    
    # Generate random sales and inventory data
    sales = round(random.uniform(1000, 5000), 2)
    inventory = round(random.uniform(500, 2000), 2)
    promotion = random.choice([True, False])
    is_holiday = random.choice([True, False])
    
    # Generate a timestamp for hourly data
    timestamp = (datetime.utcnow() - timedelta(hours=1)).replace(minute=0, second=0, microsecond=0).isoformat()
    
    # Create a JSON payload
    data = {
        'store_id': store_id,
        'department_id': department_id,
        'timestamp': timestamp,
        'store_size': store_size,
        'sales': sales,
        'inventory': inventory,
        'promotion': promotion,
        'is_holiday': is_holiday
    }
    
    return json.dumps(data).encode('utf-8')

def lambda_handler(event, context):
    stream_name = 'hourly_sales_stream'
    kinesis_client = boto3.client('kinesis')

    records = []
    # Generate 100 records
    for _ in range(100):
        data = generate_random_sales_data()
        record = {
            'Data': data,
            'PartitionKey': str(random.randint(1, 50))  # Partition key for distributing records
        }
        records.append(record)
    
    # Send the batch of records to Kinesis
    response = kinesis_client.put_records(
        StreamName=stream_name,
        Records=records
    )
    
    print(f"Batch of 100 records sent to Kinesis Stream with failed count: {response['FailedRecordCount']}")

    return {
        'statusCode': 200,
        'body': json.dumps('Batch of hourly sales data sent to Kinesis Stream successfully!')
    }
