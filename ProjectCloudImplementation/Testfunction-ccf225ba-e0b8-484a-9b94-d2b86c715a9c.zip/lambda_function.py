import boto3
import pandas as pd
import io
import json
from botocore.exceptions import ClientError

# Initialize the S3 client
s3_client = boto3.client('s3')

# S3 bucket and staging path
SOURCE_BUCKET = "mydavid125"
STAGING_PATH = "stagingsilver/"

def load_data_from_s3(bucket, key):
    """Load CSV data from an S3 bucket."""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        return pd.read_csv(io.BytesIO(response['Body'].read()))
    except ClientError as e:
        print(f"Error loading data from S3: {e}")
        raise

def check_duplicates(df):
    """Check for duplicate rows."""
    duplicates = df.duplicated().sum()
    if duplicates > 0:
        print(f"Warning: {duplicates} duplicate rows found.")
    return duplicates == 0

def check_null_values(df):
    """Check for null values."""
    null_values = df.isnull().sum().sum()
    if null_values > 0:
        print(f"Warning: {null_values} null values found.")
    return null_values == 0

def check_outliers(df, z_score_threshold=3):
    """Check for outliers using Z-score."""
    numeric_df = df.select_dtypes(include=['float64', 'int64'])
    outliers_found = False
    for column in numeric_df.columns:
        z_scores = (numeric_df[column] - numeric_df[column].mean()) / numeric_df[column].std()
        outliers = z_scores.abs() > z_score_threshold
        if outliers.sum() > 0:
            print(f"Warning: Outliers found in column {column}.")
            outliers_found = True
    return not outliers_found

def lambda_handler(event, context):
    # List of files to perform quality checks on
    files_to_check = ['features', 'past_sales', 'new_sales', 'store']
    
    quality_report = {}

    for file_prefix in files_to_check:
        prefix = f"{STAGING_PATH}{file_prefix}_"
        
        try:
            # List objects in the staging path
            response = s3_client.list_objects_v2(Bucket=SOURCE_BUCKET, Prefix=prefix)
            files = response.get('Contents', [])
            if not files:
                print(f"No files found in {STAGING_PATH} for {file_prefix}.")
                continue

            # Iterate over files for each type and perform quality checks
            for file in files:
                file_key = file['Key']
                
                # Load data from S3
                df = load_data_from_s3(SOURCE_BUCKET, file_key)
                
                # Perform quality checks
                no_duplicates = check_duplicates(df)
                no_nulls = check_null_values(df)
                no_outliers = check_outliers(df)

                # Log results for each file
                quality_report[file_key] = {
                    "no_duplicates": no_duplicates,
                    "no_nulls": no_nulls,
                    "no_outliers": no_outliers
                }
                
                print(f"Data quality check completed for {file_key}: {quality_report[file_key]}")
        
        except ClientError as e:
            print(f"Error processing files in {STAGING_PATH}: {e}")
            raise

    return {
        'statusCode': 200,
        'body': json.dumps(quality_report)
    }
