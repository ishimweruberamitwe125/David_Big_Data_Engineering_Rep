import boto3
import json
import base64
from decimal import Decimal
from datetime import datetime

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)

dynamodb = boto3.resource('dynamodb')
sns_client = boto3.client('sns')
table = dynamodb.Table('hourly_sales')
sns_topic_arn = 'arn:aws:sns:us-east-1:253490768371:Hourlysales'

def lambda_handler(event, context):
    # Check for 'Records' in the event to prevent KeyError
    if 'Records' not in event:
        print("No 'Records' key in the event")
        return {
            'statusCode': 400,
            'body': json.dumps("No records found in the event.")
        }

    for record in event['Records']:
        # Decode the Kinesis data
        base64_data = record['kinesis']['data']
        raw_data = base64.b64decode(base64_data).decode('utf-8')

        try:
            # Parse the JSON payload
            payload = json.loads(raw_data)
            
            # Extract relevant data
            store_id = payload['store_id']
            department_id = payload['department_id']
            timestamp = payload['timestamp']
            sales = Decimal(str(payload['sales']))
            inventory = Decimal(str(payload['inventory']))
            promotion = payload['promotion']
            is_holiday = payload['is_holiday']
            
            # Store data in DynamoDB
            table.put_item(
                Item={
                    'store_id': store_id,
                    'department_id': department_id,
                    'timestamp': timestamp,
                    'sales': sales,
                    'inventory': inventory,
                    'promotion': promotion,
                    'is_holiday': is_holiday
                }
            )
            print(f"Record for store {store_id}, department {department_id} loaded into DynamoDB.")
            
            # Send an SNS notification if sales exceed a certain threshold
            if sales > 4000:
                message = {
                    'store_id': store_id,
                    'department_id': department_id,
                    'timestamp': timestamp,
                    'sales': str(sales),
                    'inventory': str(inventory),
                    'promotion': promotion,
                    'is_holiday': is_holiday
                }
                response = sns_client.publish(
                    TopicArn=sns_topic_arn,
                    Message=json.dumps(message, cls=DecimalEncoder),
                    Subject='High Sales Alert'
                )
                print(f"High sales alert sent for store {store_id}, department {department_id} with MessageId: {response['MessageId']}")

        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            continue

    return {
        'statusCode': 200,
        'body': json.dumps('Data processed and stored successfully.')
    }
