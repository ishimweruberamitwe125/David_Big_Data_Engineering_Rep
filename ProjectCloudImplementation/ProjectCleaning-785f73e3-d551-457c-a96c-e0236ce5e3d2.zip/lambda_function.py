import boto3
import pandas as pd
import io
import json
from datetime import datetime
from botocore.exceptions import ClientError

# Initialize the S3 client
s3_client = boto3.client('s3')

# S3 bucket and paths
SOURCE_BUCKET = "mydavid125"
RAW_PATH = "rawbronze/toprocess/"
PROCESSED_PATH = "rawbronze/processed/"
STAGING_PATH = "stagingsilver/"

def get_latest_file(bucket, prefix):
    """Fetch the latest file from S3 with a given prefix."""
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        files = response.get('Contents', [])
        if not files:
            print(f"No files found with prefix {prefix}")
            return None
        
        # Sort files by LastModified and get the latest file
        latest_file = max(files, key=lambda x: x['LastModified'])
        return latest_file['Key']
    except ClientError as e:
        print(f"Error listing files in S3 with prefix {prefix}: {e}")
        return None

def load_data_from_s3(bucket, key):
    """Load CSV data from an S3 bucket."""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        return pd.read_csv(io.BytesIO(response['Body'].read()))
    except ClientError as e:
        print(f"Error loading data from S3: {e}")
        raise

def clean_data(df):
    """Clean data by handling missing values, outliers, and transformations."""
    # Drop duplicates
    df.drop_duplicates(inplace=True)

    # Replace 'NA' or 'na' with NaN and handle missing values
    df.replace(['NA', 'na'], pd.NA, inplace=True)
    for column in df.select_dtypes(include=['float', 'int']).columns:
        df[column] = df[column].fillna(df[column].mean())
    for column in df.select_dtypes(include=['object']).columns:
        df[column] = df[column].fillna(df[column].mode()[0])

    # Convert 'Date' column to datetime and drop 'last_modified' column
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    if 'last_modified' in df.columns:
        df.drop(columns=['last_modified'], inplace=True)

    return df

def save_to_s3_as_csv(df, bucket, file_prefix, load_type):
    """Save a DataFrame to S3 as a CSV file with a timestamp, retaining the load type."""
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    filename = f"{file_prefix}_{load_type}_transformed_{timestamp}.csv"
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)
    
    try:
        s3_client.put_object(
            Bucket=bucket,
            Key=f"{STAGING_PATH}{filename}",
            Body=csv_buffer.getvalue()
        )
        print(f"Saved cleaned file to S3: {STAGING_PATH}{filename}")
    except ClientError as e:
        print(f"Error saving data to S3: {e}")
        raise

def move_to_processed(bucket, key):
    """Move processed files to an archive path."""
    copy_source = {'Bucket': bucket, 'Key': key}
    processed_key = key.replace(RAW_PATH, PROCESSED_PATH)
    
    try:
        s3_client.copy_object(CopySource=copy_source, Bucket=bucket, Key=processed_key)
        s3_client.delete_object(Bucket=bucket, Key=key)
        print(f"Moved file from {key} to {processed_key}")
    except ClientError as e:
        print(f"Error moving file to processed folder: {e}")
        raise

def lambda_handler(event, context):
    # List of table prefixes to process
    files_to_process = ['features', 'past_sales', 'new_sales', 'store']
    
    for file_prefix in files_to_process:
        # Process both full and incremental loads
        for load_type in ['full_load', 'incremental_load']:
            prefix = f"{RAW_PATH}{file_prefix}_{load_type}_"
            
            # Get the latest file for the given prefix
            latest_file_key = get_latest_file(SOURCE_BUCKET, prefix)
            if not latest_file_key:
                print(f"No file found for {prefix}, skipping...")
                continue

            try:
                # Load data
                df = load_data_from_s3(SOURCE_BUCKET, latest_file_key)
                
                # Clean data
                cleaned_df = clean_data(df)
                
                # Save cleaned data
                save_to_s3_as_csv(cleaned_df, SOURCE_BUCKET, file_prefix, load_type)
                
                # Move original file to processed directory
                move_to_processed(SOURCE_BUCKET, latest_file_key)

            except ClientError as e:
                print(f"Error processing file {latest_file_key}: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Data cleaning and moving to processed location completed.')
    }
