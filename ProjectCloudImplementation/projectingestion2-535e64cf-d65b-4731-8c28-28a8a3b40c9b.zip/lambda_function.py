import json
import boto3
import os
import time
import psycopg2
import csv
from datetime import datetime
from botocore.exceptions import ClientError
from io import StringIO

# Initialize the S3 client
s3_client = boto3.client('s3')

# PostgreSQL connection details
DB_HOST = "ec2-18-132-73-146.eu-west-2.compute.amazonaws.com"
DB_NAME = "testdb"
DB_USER = "consultants"
DB_PASSWORD = "WelcomeItc@2022"

# S3 bucket and paths
S3_BUCKET = "mydavid125"
RAW_PATH = "rawbronze/toprocess/"

# Dictionary to keep track of the latest timestamp for each table
last_modified_times = {
    "features": None,
    "past_sales": None,
    "new_sales": None,
    "store": None
}

def connect_to_postgres():
    """Connect to the PostgreSQL database."""
    try:
        connection = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        return connection
    except Exception as e:
        print(f"Error connecting to PostgreSQL: {e}")
        raise

def fetch_data_from_postgres(query):
    """Fetch data from PostgreSQL."""
    connection = connect_to_postgres()
    cursor = connection.cursor()
    cursor.execute(query)
    columns = [desc[0] for desc in cursor.description]
    records = cursor.fetchall()
    cursor.close()
    connection.close()
    # Convert records to a list of dictionaries
    data = [dict(zip(columns, record)) for record in records]
    return data

def upload_to_s3_as_csv(data, filename):
    """Upload data to S3 as a CSV file."""
    try:
        # Convert data to CSV format
        csv_buffer = StringIO()
        writer = csv.DictWriter(csv_buffer, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

        # Upload CSV content to S3
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=f"{RAW_PATH}{filename}",
            Body=csv_buffer.getvalue()
        )
        print(f"Uploaded {filename} to S3.")
    except ClientError as e:
        print(f"Error uploading to S3: {e}")
        raise

def perform_full_load(table_name):
    """Perform the full load of data from PostgreSQL for a given table."""
    global last_modified_times
    full_load_query = f"SELECT * FROM {table_name} ORDER BY last_modified LIMIT 1000"
    data = fetch_data_from_postgres(full_load_query)

    if data:
        print(f"Full load data fetched successfully for {table_name}.")
        full_load_filename = f"{table_name}_full_load_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
        upload_to_s3_as_csv(data, full_load_filename)

        # Update the last_modified_time for the table
        last_modified_times[table_name] = data[-1]['last_modified']
    else:
        print(f"No data to upload for the full load of {table_name}.")

def perform_incremental_load(table_name):
    """Perform a single incremental load from PostgreSQL for a given table."""
    global last_modified_times
    last_modified_time = last_modified_times.get(table_name)
    if not last_modified_time:
        print(f"No last_modified_time found for {table_name}. Please perform a full load first.")
        return

    incremental_query = f"""
    SELECT * FROM {table_name}
    WHERE last_modified > '{last_modified_time}'
    ORDER BY last_modified
    LIMIT 100
    """
    incremental_data = fetch_data_from_postgres(incremental_query)

    if incremental_data:
        increment_filename = f"{table_name}_incremental_load_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
        upload_to_s3_as_csv(incremental_data, increment_filename)

        # Update the last_modified_time for the table
        last_modified_times[table_name] = incremental_data[-1]['last_modified']
    else:
        print(f"No more data to upload for the incremental load of {table_name}.")

def lambda_handler(event, context):
    # List of tables to process
    tables = ["features", "past_sales", "new_sales", "store"]

    # Perform full load for all tables if it's the first run
    if all(last_modified_times[table] is None for table in tables):
        print("Performing full load for all tables...")
        for table in tables:
            perform_full_load(table)
    else:
        print("Performing incremental load for all tables...")
        for table in tables:
            perform_incremental_load(table)

    return {
        'statusCode': 200,
        'body': json.dumps('Data loading completed.')
    }
